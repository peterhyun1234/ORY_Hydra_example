---
name: Support request
about: Please use our forums (community.ory.sh) or the chat (ory.sh/chat) to ask for support

---

Please use issues only to file potential bugs or request features. For everything else please go to
the [ORY Community](https://community.ory.sh/) or join the [ORY Chat](https://www.ory.sh/chat).
