The [documentation](https://www.ory.sh/docs) has moved to [another GitHub repository](https://github.com/ory/docs).
